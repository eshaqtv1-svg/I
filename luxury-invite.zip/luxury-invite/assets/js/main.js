/* ==========================================================================
   سارا و آرمین — main.js
   All interactions for the invitation: preloader, cursor, reveal-on-scroll,
   countdown, timeline progress, gallery lightbox, RSVP, add-to-calendar,
   copy-to-clipboard, music toggle, petal field.
   ========================================================================== */

/* ---------- CONFIG — edit these to personalize the invitation ---------- */
const CONFIG = {
  brideName: "سارا",
  groomName: "آرمین",
  weddingDateISO: "2025-10-06T18:00:00+03:30", // ceremony start
  ceremony: {
    title: "عقد و پذیرایی",
    time: "ساعت ۱۸:۰۰",
    address: "تهران، خیابان ولیعصر، باغ تالار سرو، سالن یاس",
    mapUrl: "https://maps.google.com"
  },
  reception: {
    title: "جشن شام",
    time: "ساعت ۲۱:۰۰",
    address: "همان مکان مراسم عقد — سالن اصلی باغ",
    mapUrl: "https://maps.google.com"
  },
  cardNumber: "6037-9975-XXXX-XXXX"
};

document.addEventListener('DOMContentLoaded', () => {
  initPreloader();
  initCursor();
  initPetals();
  initReveal();
  initVines();
  initProgress();
  initNavDots();
  initCountdown();
  initTimelineProgress();
  initGallery();
  initRsvp();
  initStepper();
  initGift();
  initMusic();
  initCalendarButtons();
});

/* ---------------- preloader ---------------- */
function initPreloader(){
  const pre = document.getElementById('preloader');
  if(!pre) return;
  document.body.classList.add('locked');
  const finish = () => {
    pre.classList.add('open');
    document.body.classList.remove('locked');
    setTimeout(() => { pre.style.display = 'none'; }, 1200);
  };
  // wait for fonts + a minimum show time so the monogram draw is visible
  const minDelay = new Promise(res => setTimeout(res, 2200));
  const fontsReady = document.fonts ? document.fonts.ready : Promise.resolve();
  Promise.all([minDelay, fontsReady]).then(finish);
}

/* ---------------- custom cursor ---------------- */
function initCursor(){
  if (window.matchMedia('(pointer: coarse)').matches) return;
  const dot = document.querySelector('.cursor-dot');
  const ring = document.querySelector('.cursor-ring');
  if(!dot || !ring) return;
  let mx = 0, my = 0, rx = 0, ry = 0;
  window.addEventListener('mousemove', e => {
    mx = e.clientX; my = e.clientY;
    dot.style.transform = `translate(${mx}px, ${my}px) translate(-50%,-50%)`;
  });
  (function loop(){
    rx += (mx - rx) * 0.16;
    ry += (my - ry) * 0.16;
    ring.style.transform = `translate(${rx}px, ${ry}px) translate(-50%,-50%)`;
    requestAnimationFrame(loop);
  })();
  document.querySelectorAll('a, button, .g-item, input').forEach(el => {
    el.addEventListener('mouseenter', () => ring.classList.add('active'));
    el.addEventListener('mouseleave', () => ring.classList.remove('active'));
  });
}

/* ---------------- falling petals ---------------- */
function initPetals(){
  const host = document.getElementById('petal-layer');
  if(!host) return;
  const glyphs = ['❀','✿','❁'];
  const count = window.innerWidth < 640 ? 10 : 16;
  for(let i=0;i<count;i++){
    const p = document.createElement('div');
    p.className = 'petal';
    p.textContent = glyphs[Math.floor(Math.random()*glyphs.length)];
    p.style.left = Math.random()*100+'vw';
    p.style.fontSize = (10+Math.random()*14)+'px';
    p.style.animationDuration = (12+Math.random()*12)+'s';
    p.style.animationDelay = (Math.random()*14)+'s';
    host.appendChild(p);
  }
}

/* ---------------- generic reveal-on-scroll ---------------- */
function initReveal(){
  const els = document.querySelectorAll('.reveal');
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => { if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); } });
  }, { threshold: 0.15 });
  els.forEach(el => io.observe(el));
}

/* ---------------- vine dividers draw-in ---------------- */
function initVines(){
  const vines = document.querySelectorAll('.vine');
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => { if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); } });
  }, { threshold: 0.4 });
  vines.forEach(v => io.observe(v));
}

/* ---------------- scroll progress rail ---------------- */
function initProgress(){
  const fill = document.querySelector('.progress-fill');
  if(!fill) return;
  window.addEventListener('scroll', () => {
    const h = document.documentElement;
    const pct = (h.scrollTop) / (h.scrollHeight - h.clientHeight) * 100;
    fill.style.height = pct + '%';
  }, { passive:true });
}

/* ---------------- side nav dots ---------------- */
function initNavDots(){
  const dotsHost = document.querySelector('.nav-dots');
  if(!dotsHost) return;
  const targets = document.querySelectorAll('[data-nav]');
  targets.forEach(t => {
    const a = document.createElement('a');
    a.href = '#' + t.id;
    a.title = t.dataset.nav;
    dotsHost.appendChild(a);
  });
  const links = dotsHost.querySelectorAll('a');
  const io = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if(e.isIntersecting){
        links.forEach(l => l.classList.remove('active'));
        const idx = [...targets].indexOf(e.target);
        if(links[idx]) links[idx].classList.add('active');
      }
    });
  }, { threshold: 0.5 });
  targets.forEach(t => io.observe(t));
}

/* ---------------- countdown ---------------- */
function initCountdown(){
  const target = new Date(CONFIG.weddingDateISO).getTime();
  const els = {
    d: document.getElementById('cd-days'),
    h: document.getElementById('cd-hours'),
    m: document.getElementById('cd-min'),
    s: document.getElementById('cd-sec')
  };
  if(!els.d) return;
  const toFa = n => n.toLocaleString('fa-IR');
  let prev = {};
  function tick(){
    const diff = Math.max(0, target - Date.now());
    const d = Math.floor(diff/86400000);
    const h = Math.floor(diff/3600000)%24;
    const m = Math.floor(diff/60000)%60;
    const s = Math.floor(diff/1000)%60;
    const vals = { d, h, m, s };
    Object.entries(vals).forEach(([k,v]) => {
      if(prev[k] !== v){
        els[k].classList.add('tick');
        setTimeout(() => {
          els[k].textContent = toFa(v);
          els[k].classList.remove('tick');
        }, 180);
      }
    });
    prev = vals;
  }
  tick();
  setInterval(tick, 1000);
}

/* ---------------- timeline vertical progress ---------------- */
function initTimelineProgress(){
  const track = document.querySelector('.timeline-track .fill');
  const timeline = document.querySelector('.timeline');
  if(!track || !timeline) return;
  window.addEventListener('scroll', () => {
    const rect = timeline.getBoundingClientRect();
    const vh = window.innerHeight;
    const total = rect.height;
    const scrolled = Math.min(Math.max(vh*0.6 - rect.top, 0), total);
    track.style.height = (scrolled/total*100) + '%';
  }, { passive:true });
}

/* ---------------- gallery lightbox ---------------- */
function initGallery(){
  const items = document.querySelectorAll('.g-item');
  const lb = document.getElementById('lightbox');
  if(!items.length || !lb) return;
  const lbImg = lb.querySelector('img');
  let list = [...items].map(i => i.dataset.full || i.querySelector('img')?.src || '');
  let idx = 0;
  function open(i){
    idx = i;
    const src = list[idx];
    if(!src) return; // placeholder tile with no photo yet
    lbImg.src = src;
    lb.classList.add('open');
  }
  items.forEach((el, i) => el.addEventListener('click', () => open(i)));
  lb.querySelector('.lb-close').addEventListener('click', () => lb.classList.remove('open'));
  lb.querySelector('.lb-prev').addEventListener('click', () => open((idx-1+list.length)%list.length));
  lb.querySelector('.lb-next').addEventListener('click', () => open((idx+1)%list.length));
  lb.addEventListener('click', e => { if(e.target === lb) lb.classList.remove('open'); });
  document.addEventListener('keydown', e => {
    if(!lb.classList.contains('open')) return;
    if(e.key === 'Escape') lb.classList.remove('open');
    if(e.key === 'ArrowLeft') open((idx-1+list.length)%list.length);
    if(e.key === 'ArrowRight') open((idx+1)%list.length);
  });
}

/* ---------------- RSVP form ---------------- */
function initRsvp(){
  const form = document.getElementById('rsvpForm');
  const thanks = document.getElementById('thanksMsg');
  if(!form) return;

  document.querySelectorAll('.attend-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.attend-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  form.addEventListener('submit', e => {
    e.preventDefault();
    const btn = form.querySelector('.submit-btn');
    btn.classList.add('loading');
    // Simulated submit — replace with your own endpoint (Formspree, Sheet, email API, etc.)
    setTimeout(() => {
      btn.classList.remove('loading');
      form.style.display = 'none';
      thanks.style.display = 'block';
      burstPetals();
    }, 900);
  });
}

function initStepper(){
  const val = document.querySelector('.stepper .val');
  const input = document.getElementById('guestCount');
  if(!val) return;
  let n = 0;
  document.querySelector('.stepper .minus').addEventListener('click', () => {
    n = Math.max(0, n-1); val.textContent = n.toLocaleString('fa-IR'); if(input) input.value = n;
  });
  document.querySelector('.stepper .plus').addEventListener('click', () => {
    n = Math.min(10, n+1); val.textContent = n.toLocaleString('fa-IR'); if(input) input.value = n;
  });
}

function burstPetals(){
  const host = document.getElementById('petal-layer');
  if(!host) return;
  for(let i=0;i<24;i++){
    const p = document.createElement('div');
    p.className = 'petal';
    p.textContent = '❀';
    p.style.left = (40+Math.random()*20)+'vw';
    p.style.top = '40vh';
    p.style.fontSize = (12+Math.random()*10)+'px';
    p.style.animation = `fall ${2+Math.random()*2}s ease-in forwards`;
    host.appendChild(p);
    setTimeout(() => p.remove(), 4200);
  }
}

/* ---------------- gift card copy ---------------- */
function initGift(){
  const numEl = document.getElementById('cardNumber');
  const btn = document.querySelector('.copy-btn');
  const hint = document.querySelector('.copy-hint');
  if(!numEl) return;
  numEl.textContent = CONFIG.cardNumber;
  if(!btn) return;
  btn.addEventListener('click', () => {
    navigator.clipboard?.writeText(CONFIG.cardNumber.replace(/-/g,'')).then(() => {
      hint.classList.add('show');
      setTimeout(() => hint.classList.remove('show'), 1800);
    });
  });
}

/* ---------------- music toggle ---------------- */
function initMusic(){
  const btn = document.getElementById('musicBtn');
  const audio = document.getElementById('bgAudio');
  if(!btn) return;
  let playing = false;
  btn.addEventListener('click', () => {
    playing = !playing;
    btn.classList.toggle('playing', playing);
    if(!audio) return;
    if(playing){
      audio.play().catch(() => {
        console.warn('یک فایل صوتی در assets/audio/song.mp3 قرار دهید تا موزیک پخش شود.');
      });
    } else {
      audio.pause();
    }
  });
}

/* ---------------- add to calendar (.ics) ---------------- */
function initCalendarButtons(){
  document.querySelectorAll('[data-ics]').forEach(btn => {
    btn.addEventListener('click', () => {
      const which = btn.dataset.ics;
      const info = which === 'ceremony' ? CONFIG.ceremony : CONFIG.reception;
      downloadIcs(info, CONFIG);
    });
  });
}
function downloadIcs(info, cfg){
  const start = new Date(cfg.weddingDateISO);
  const end = new Date(start.getTime() + 3*60*60*1000);
  const fmt = d => d.toISOString().replace(/[-:]/g,'').split('.')[0]+'Z';
  const ics = [
    'BEGIN:VCALENDAR','VERSION:2.0','BEGIN:VEVENT',
    `SUMMARY:${info.title} — ${cfg.brideName} و ${cfg.groomName}`,
    `DTSTART:${fmt(start)}`,`DTEND:${fmt(end)}`,
    `LOCATION:${info.address}`,
    `DESCRIPTION:${info.title}`,
    'END:VEVENT','END:VCALENDAR'
  ].join('\r\n');
  const blob = new Blob([ics], { type:'text/calendar' });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = 'wedding-event.ics';
  a.click();
}
